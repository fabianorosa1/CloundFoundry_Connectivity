package com.sap.cloud.sample.connectivity.cf;

public interface RouteProvider {
	public Route getRoute(String path);
}
